// @desc get all contacts
//@route get api/contacts
// @access public
const asyncHandler=require("express-async-handler");

const Contact=require("../models/contactModel");
const getContacts=asyncHandler(async(req,res)=>{

    const contacts=await Contact.find({user_id:req.user.id});
    res.status(200).json(contacts);
});
const createContact=asyncHandler(async(req,res)=>{
    console.log("this is the request body"+req.body)
    const {name,email,phone}=req.body;
    console.log(name,":",email,"",phone)
    if(!name || !email || !phone){
        res.status(400)
        throw new Error("invaild object")
     }
    const contact=await Contact.create({
       name,
        email,
        phone,
        user_id:req.user.id,
     });
    res.status(201).json(contact)
});
const getContact=asyncHandler(async(req,res)=>{
    const contact=await Contact.findById(req.params.id);
    if(!contact){
        res.status(404);
        throw new Error("There is no such contact exist");
    }
    res.status(201).json(contact);
});
const updateContact=asyncHandler(async(req,res)=>{
    const contact=await Contact.findById(req.params.id);
    if(!contact){
        res.status(404);
        throw new Error("There is no such contact exist");
    }
    if(contact.user_id.toString()!=req.user.id){
        res.status(403);
        throw new Error("this user is not accessed to update other user contact");
    }
    const updatedcontact=await Contact.findByIdAndUpdate(
        req.params.id,
        req.body,
        {new :true}
    );
    res.status(201).json(updateContact);
});
const deleteContact=asyncHandler(async(req,res)=>{
    const contact=await Contact.findById(req.params.id);
    console.log(contact);
    if(!contact){
        res.status(404);
        throw new Error("There is no such contact exist");
    }
    if(contact.user_id.toString()!=req.user.id){
        res.status(403);
        throw new Error("this user is not accessed to update other user contact");
    }
  await Contact.deleteOne({_id:req.params.id});
     res.status(200).json(contact);
});

module.exports=
{
getContacts
,createContact
,getContact
,updateContact
,deleteContact};