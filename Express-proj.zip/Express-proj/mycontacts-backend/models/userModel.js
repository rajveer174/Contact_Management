const mongoose=require("mongoose");

const userSchema=mongoose.Schema({
    username:{
        type:String,
        required:[true,"please add the usename"],
    },
    email:{
        type:String,
        required:[true,"please add the email as well"],
        unique:[true,"Email address is alreay taken"],
    },
    password:{
        type:String,
        require:[true,"Please enter the password"],
    },
},{
    timestamps:true,
}
)

module.exports=mongoose.model("User",userSchema);